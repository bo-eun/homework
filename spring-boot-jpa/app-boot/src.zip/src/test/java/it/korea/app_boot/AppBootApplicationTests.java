package it.korea.app_boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
