package it.korea.app_boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppBootApplication.class, args);
	}

}
