package kr.study.game.data;

public enum Hands {
	
	GAWI(1, "가위"),
	BAWI(2, "바위"),
	BO(3,   "보");
	
	private int value;
	private String name;
	
	
	private Hands( int value, String name) {
		this.value = value;
		this.name = name;
	}
	
	public String getName() {
		return this.name;
	}
	
	public int getValue() {
		return this.value;
	}
	
	
	 public static Hands getHand(int value) {
		 for(Hands h :  Hands.values()) {
			 if(h.getValue() == value) {
				 return h;
			 }
		 }
		 
		//이후 코드는 없기 때문에 return 없어도 에러가 안나는 것
		 throw new IllegalArgumentException("No seachType : " + value); 
	 }
	
	
	
}
